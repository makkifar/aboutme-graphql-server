"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const apollo_server_lambda_1 = require("apollo-server-lambda");
const articles_1 = require("./data-sources/articles");
const typeDefs = apollo_server_lambda_1.gql `
  type Article {
    articleId: String
    title: String
    content: String
  }

  type Query {
    articles: [Article]
    article(articleId: String): Article
  }
`;
const resolvers = {
    Query: {
        articles: (_source, _args, { dataSources }) => __awaiter(void 0, void 0, void 0, function* () {
            return yield dataSources.articlesAPI.getArticles();
        }),
        article: (_source, { articleId }, { dataSources }) => __awaiter(void 0, void 0, void 0, function* () {
            return yield dataSources.articlesAPI.getArticle(articleId);
        })
    }
};
const server = new apollo_server_lambda_1.ApolloServer({
    typeDefs,
    resolvers,
    dataSources: () => ({
        articlesAPI: new articles_1.ArticlesAPI()
    })
});
exports.graphqlHandler = server.createHandler({
    cors: {
        origin: '*',
        credentials: false
    }
});
