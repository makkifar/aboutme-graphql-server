
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'makkifarah1992',
  applicationName: 'apollo-lambda-app',
  appUid: 'BwJkbtglSw03r79MnR',
  orgUid: 'JvN1BxTcm1PsgZt5qd',
  deploymentUid: '3c2f2297-6232-4613-937e-dca970923167',
  serviceName: 'apollo-lambda',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'production',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '3.6.13',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'apollo-lambda-production-graphql', timeout: 6 };

try {
  const userHandler = require('./src/graphql.js');
  module.exports.handler = serverlessSDK.handler(userHandler.graphqlHandler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}