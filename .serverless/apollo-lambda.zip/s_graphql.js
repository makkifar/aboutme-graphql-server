
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'makkifarah1992',
  applicationName: 'apollo-lambda-app',
  appUid: 'BwJkbtglSw03r79MnR',
  orgUid: 'JvN1BxTcm1PsgZt5qd',
  deploymentUid: 'd405c98f-3df5-4fe4-a478-29f42aaba42b',
  serviceName: 'apollo-lambda',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '3.6.13',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'apollo-lambda-dev-graphql', timeout: 6 };

try {
  const userHandler = require('./src/index.js');
  module.exports.handler = serverlessSDK.handler(userHandler.graphqlHandler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}